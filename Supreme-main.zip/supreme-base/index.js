/*
 Give credits to Kevin dev
 Contact me at 256742932677
 Base creator and pterodactyl panels seller.
 
 Enhanced with JUNE X components
 © 2025 supreme
*/

process.on("uncaughtException", (err) => {
    console.error("Caught exception:", err);
});

console.clear();
console.log('Starting...');

// --- Environment Setup ---
//require('dotenv').config();
require('./setting/config');

const { 
    default: makeWASocket, 
    useMultiFileAuthState, 
    DisconnectReason, 
    jidDecode, 
    downloadContentFromMessage,
    fetchLatestBaileysVersion,
    jidNormalizedUser,
    makeCacheableSignalKeyStore
} = require("@whiskeysockets/baileys");

const pino = require('pino');
const chalk = require('chalk');
const readline = require("readline");
const FileType = require('file-type');
const fs = require('fs');
const path = require('path');
const axios = require('axios');
const os = require('os');
const PhoneNumber = require('awesome-phonenumber');
const NodeCache = require("node-cache");

const {
    Boom 
} = require('@hapi/boom');

const {
    smsg,
    formatSize, 
    isUrl, 
    generateMessageTag,
    getBuffer,
    getSizeMedia, 
    runtime, 
    fetchJson, 
    sleep 
} = require('./start/lib/myfunction');
const PluginManager = require('./start/lib/PluginManager');

// --- 🌟 Centralized Logging Function ---
function log(message, color = 'white', isError = false) {
    const prefix = chalk.magenta.bold('[ KELVIN-X ]');
    const logFunc = isError ? console.error : console.log;
    const coloredMessage = chalk[color](message);
    
    if (message.includes('\n') || message.includes('════')) {
        logFunc(prefix, coloredMessage);
    } else {
        logFunc(`${prefix} ${coloredMessage}`);
    }
}

// --- Question function for pairing code input ---
function question(query) {
    const rl = readline.createInterface({
        input: process.stdin,
        output: process.stdout
    });
    return new Promise(resolve => rl.question(query, ans => {
        rl.close();
        resolve(ans);
    }));
}

// --- GLOBAL FLAGS ---
global.isBotConnected = false;
global.connectDebounceTimeout = null;
global.errorRetryCount = 0;
global.pairingRetryCount = 0;
global.botname = "SUPREME X";
global.themeemoji = "•";

// --- Constants ---
const MAX_RETRIES = 3;
const MAX_PAIRING_RETRIES = 3;
const PAIRING_CODE_TIMEOUT = 60000; // 60 seconds
const CONNECTION_TIMEOUT = 120000; // 2 minutes

// --- Path Configuration ---
const sessionDir = path.join(__dirname, 'session');
const credsPath = path.join(sessionDir, 'creds.json');
const loginFile = path.join(sessionDir, 'login.json');
const envPath = path.join(process.cwd(), '.env');

// --- 🔒 MESSAGE/ERROR STORAGE CONFIGURATION ---
const MESSAGE_STORE_FILE = path.join(__dirname, 'message_backup.json');
const SESSION_ERROR_FILE = path.join(__dirname, 'sessionErrorCount.json');
global.messageBackup = {};

function loadStoredMessages() {
    try {
        if (fs.existsSync(MESSAGE_STORE_FILE)) {
            const data = fs.readFileSync(MESSAGE_STORE_FILE, 'utf-8');
            return JSON.parse(data);
        }
    } catch (error) {
        log(`Error loading message backup store: ${error.message}`, 'red', true);
    }
    return {};
}

function saveStoredMessages(data) {
    try {
        fs.writeFileSync(MESSAGE_STORE_FILE, JSON.stringify(data, null, 2));
    } catch (error) {
        log(`Error saving message backup store: ${error.message}`, 'red', true);
    }
}

function loadErrorCount() {
    try {
        if (fs.existsSync(SESSION_ERROR_FILE)) {
            const data = fs.readFileSync(SESSION_ERROR_FILE, 'utf-8');
            return JSON.parse(data);
        }
    } catch (error) {
        log(`Error loading session error count: ${error.message}`, 'red', true);
    }
    return { count: 0, last_error_timestamp: 0 };
}

function saveErrorCount(data) {
    try {
        fs.writeFileSync(SESSION_ERROR_FILE, JSON.stringify(data, null, 2));
    } catch (error) {
        log(`Error saving session error count: ${error.message}`, 'red', true);
    }
}

function deleteErrorCountFile() {
    try {
        if (fs.existsSync(SESSION_ERROR_FILE)) {
            fs.unlinkSync(SESSION_ERROR_FILE);
            log('✅ Deleted sessionErrorCount.json.', 'red');
        }
    } catch (e) {
        log(`Failed to delete sessionErrorCount.json: ${e.message}`, 'red', true);
    }
}

// --- Session Management Functions ---
async function saveLoginMethod(method) {
    await fs.promises.mkdir(sessionDir, { recursive: true });
    await fs.promises.writeFile(loginFile, JSON.stringify({ method }, null, 2));
}

async function getLastLoginMethod() {
    if (fs.existsSync(loginFile)) {
        const data = JSON.parse(fs.readFileSync(loginFile, 'utf-8'));
        return data.method;
    }
    return null;
}

function sessionExists() {
    return fs.existsSync(credsPath);
}

function clearSessionFiles() {
    try {
        log('🗑️ Clearing session folder...', 'blue');
        fs.rmSync(sessionDir, { recursive: true, force: true });
        if (fs.existsSync(loginFile)) fs.unlinkSync(loginFile);
        deleteErrorCountFile();
        global.errorRetryCount = 0;
        global.pairingRetryCount = 0;
        log('✅ Session files cleaned successfully.', 'green');
    } catch (e) {
        log(`Failed to clear session files: ${e.message}`, 'red', true);
    }
}

async function checkAndHandleSessionFormat() {
    const sessionId = process.env.SESSION_ID;
    
    if (sessionId && sessionId.trim() !== '') {
        if (!sessionId.trim().startsWith('KELVIN-MD')) {
            log(chalk.white.bgRed('[ERROR]: Invalid SESSION_ID in .env'), 'white');
            log(chalk.white.bgRed('[SESSION ID] MUST start with "KELVIN-MD".'), 'white');
            log(chalk.white.bgRed('Cleaning .env and creating new one...'), 'white');
            
            try {
                let envContent = fs.readFileSync(envPath, 'utf8');
                envContent = envContent.replace(/^SESSION_ID=.*$/m, 'SESSION_ID=');
                fs.writeFileSync(envPath, envContent);
                log('✅ Cleaned SESSION_ID entry in .env file.', 'green');
                log('Please add a proper session ID and restart the bot.', 'yellow');
            } catch (e) {
                log(`Failed to modify .env file: ${e.message}`, 'red', true);
            }
            
            log('Bot will wait 30 seconds then restart', 'blue');
            await sleep(20000);
            process.exit(1);
        }
    }
}

async function downloadSessionData() {
    try {
        await fs.promises.mkdir(sessionDir, { recursive: true });
        if (!fs.existsSync(credsPath) && global.SESSION_ID) {
            const base64Data = global.SESSION_ID.includes("KELVIN-MD:~") ? 
                global.SESSION_ID.split("KELVIN-MD:~")[1] : global.SESSION_ID;
            const sessionData = Buffer.from(base64Data, 'base64');
            await fs.promises.writeFile(credsPath, sessionData);
            log(`Session successfully saved.`, 'green');
        }
    } catch (err) { 
        log(`Error downloading session data: ${err.message}`, 'red', true); 
    }
}

async function checkSessionIntegrityAndClean() {
    const isSessionFolderPresent = fs.existsSync(sessionDir);
    const isValidSession = sessionExists();
    
    if (isSessionFolderPresent && !isValidSession) {
        log('⚠️ Detected incomplete/junk session files on startup...', 'red');
        log('✅ Cleaning up before proceeding...', 'yellow');
        clearSessionFiles();
        log('Cleanup complete. Waiting 3 seconds for stability...', 'yellow');
        await sleep(3000);
    }
}

function cleanupOldMessages() {
    let storedMessages = loadStoredMessages();
    let now = Math.floor(Date.now() / 1000);
    const maxMessageAge = 24 * 60 * 60;
    let cleanedMessages = {};
    
    for (let chatId in storedMessages) {
        let newChatMessages = {};
        for (let messageId in storedMessages[chatId]) {
            let message = storedMessages[chatId][messageId];
            if (now - message.timestamp <= maxMessageAge) {
                newChatMessages[messageId] = message;
            }
        }
        if (Object.keys(newChatMessages).length > 0) {
            cleanedMessages[chatId] = newChatMessages;
        }
    }
    saveStoredMessages(cleanedMessages);
    log("🧹 [Msg Cleanup] Old messages removed from message_backup.json", 'yellow');
}

function cleanupJunkFiles(botSocket) {
    let directoryPath = path.join(__dirname);
    fs.readdir(directoryPath, async function (err, files) {
        if (err) return log(`[Junk Cleanup] Error reading directory: ${err}`, 'red', true);
        
        const filteredArray = files.filter(item =>
            item.endsWith(".gif") || item.endsWith(".png") || item.endsWith(".mp3") ||
            item.endsWith(".mp4") || item.endsWith(".opus") || item.endsWith(".jpg") ||
            item.endsWith(".webp") || item.endsWith(".webm") || item.endsWith(".zip")
        );
        
        if (filteredArray.length > 0) {
            let teks = `Detected ${filteredArray.length} junk files,\nJunk files have been deleted🚮`;
            
            if (botSocket && botSocket.user && botSocket.user.id) {
                botSocket.sendMessage(botSocket.user.id.split(':')[0] + '@s.whatsapp.net', { text: teks });
            }
            
            filteredArray.forEach(function (file) {
                const filePath = path.join(directoryPath, file);
                try {
                    if (fs.existsSync(filePath)) fs.unlinkSync(filePath);
                } catch (e) {
                    log(`[Junk Cleanup] Failed to delete ${file}: ${e.message}`, 'red', true);
                }
            });
            log(`[Junk Cleanup] ${filteredArray.length} files deleted.`, 'yellow');
        }
    });
}

// Improved 408 error handler
async function handle408Error(error) {
    let statusCode = null;
    let isTimeout = false;
    
    // Extract status code from various possible error formats
    if (error) {
        if (error.output?.statusCode) {
            statusCode = error.output.statusCode;
        } else if (error.statusCode) {
            statusCode = error.statusCode;
        } else if (error.code) {
            statusCode = error.code;
        }
        
        // Check for timeout indicators
        isTimeout = statusCode === DisconnectReason.timedOut || 
                   statusCode === 408 ||
                   error.message?.toLowerCase().includes('timeout') ||
                   error.message?.toLowerCase().includes('timedout') ||
                   error.message?.includes('Connection closed') ||
                   error.toString().toLowerCase().includes('timeout');
    }
    
    if (!isTimeout) return false;
    
    global.errorRetryCount++;
    let errorState = loadErrorCount();
    
    errorState.count = global.errorRetryCount;
    errorState.last_error_timestamp = Date.now();
    saveErrorCount(errorState);

    log(`⚠️ Connection Timeout (408) detected. Retry count: ${global.errorRetryCount}/${MAX_RETRIES}`, 'yellow');
    
    if (global.errorRetryCount >= MAX_RETRIES) {
        log(chalk.white.bgRed(`\n❌ [MAX CONNECTION TIMEOUTS] (${MAX_RETRIES}) REACHED.`), 'white');
        log(chalk.white.bgRed('Exiting process to stop infinite restart loop.'), 'white');

        deleteErrorCountFile();
        global.errorRetryCount = 0;
        await sleep(5000);
        process.exit(1);
    }
    
    // Wait before reconnecting
    log(`⏳ Waiting 5 seconds before reconnection attempt...`, 'blue');
    await sleep(5000);
    return true;
}

function detectPlatform() {
    if (process.env.DYNO) return "☁️ Heroku";
    if (process.env.RENDER) return "⚡ Render";
    if (process.env.PREFIX && process.env.PREFIX.includes("termux")) return "📱 Termux";
    if (process.env.PORTS && process.env.CYPHERX_HOST_ID) return "🌀 CypherX Platform";
    if (process.env.P_SERVER_UUID) return "🖥️ Panel";
    if (process.env.LXC) return "📦 Linux Container";
    
    switch (os.platform()) {
        case "win32": return "🪟 Windows";
        case "darwin": return "🍎 macOS";
        case "linux": return "🐧 Linux";
        default: return "❓ Unknown";
    }
}

async function sendWelcomeMessage(kelvin) {
    if (global.isBotConnected) return;
    
    await sleep(10000);

    if (!kelvin.user || global.isBotConnected) return;

    global.isBotConnected = true;
    const hostName = detectPlatform();
    const pNumber = kelvin.user.id.split(':')[0] + '@s.whatsapp.net';
    
    try {
        await kelvin.sendMessage(pNumber, {
            text: `
┏━━━━━✧ CONNECTED ✧━━━━━━━
┃✧ Bot: KELVIN-X
┃✧ Platform: ${hostName}
┃✧ Status: Active
┃✧ Time: ${new Date().toLocaleString()}
┃✧ Contact: 256742932677
┗━━━━━━━━━━━━━━━━━━━━━`
        });
        log('✅ Bot successfully connected to Whatsapp.', 'green');

        // Auto join support group
        try {
            await kelvin.groupAcceptInvite("LFsUyjB5AM8IDhhrxULLUS");
            console.log(chalk.blue(`✅ Auto-joined WhatsApp group successfully`));
        } catch (e) {
            console.log(chalk.red(`🚫 Failed to join WhatsApp group: ${e}`));
        }

        deleteErrorCountFile();
        global.errorRetryCount = 0;
        global.pairingRetryCount = 0;
    } catch (e) {
        log(`Error sending welcome message: ${e.message}`, 'red', true);
        global.isBotConnected = false;
    }
}

function checkEnvStatus() {
    try {
        log(`║ [WATCHER] .env ║`, 'green');
        
        fs.watch(envPath, { persistent: false }, (eventType, filename) => {
            if (filename && eventType === 'change') {
                log(chalk.bgRed.black('================================================='), 'white');
                log(chalk.white.bgRed(' [ENV] env file change detected!'), 'white');
                log(chalk.white.bgRed('Forcing a clean restart to apply new configuration.'), 'white');
                log(chalk.red.bgBlack('================================================='), 'white');
                process.exit(1);
            }
        });
    } catch (e) {
        log(`❌ Failed to set up .env file watcher: ${e.message}`, 'red', true);
    }
}

const { makeInMemoryStore } = require("./start/lib/store/");

async function loadAllPlugins() {
    try {
        const pluginManager = new PluginManager();
        const pluginsDir = path.join(__dirname, 'Plugins');
        
        if (!fs.existsSync(pluginsDir)) {
            fs.mkdirSync(pluginsDir, { recursive: true });
            console.log(chalk.yellow(`📁 Created plugins directory: ${pluginsDir}`));
        }
        
        const count = pluginManager.loadPlugins(pluginsDir);
        console.log(chalk.green(`✅ Loaded ${count} plugins successfully!`));
        global.pluginManager = pluginManager;
        return count;
    } catch (error) {
        console.error(chalk.red(`Error loading plugins: ${error.message}`));
        return 0;
    }
}

const store = makeInMemoryStore({
    logger: pino().child({
        level: 'silent',
        stream: 'store'
    })
});

async function kelvinstart() {
    // Check session format first
    await checkAndHandleSessionFormat();
    
    // Load error count
    const errorState = loadErrorCount();
    global.errorRetryCount = errorState.count;
    
    // Check if we've exceeded max retries recently
    const timeSinceLastError = Date.now() - (errorState.last_error_timestamp || 0);
    if (global.errorRetryCount >= MAX_RETRIES && timeSinceLastError < 60000) { // 1 minute
        log(chalk.white.bgRed(`\n❌ Too many recent connection timeouts. Waiting 2 minutes before retry...`), 'white');
        await sleep(120000);
        // Reset counter after waiting
        global.errorRetryCount = 0;
        deleteErrorCountFile();
    }
    
    log(`Retrieved initial retry count: ${global.errorRetryCount}`, 'yellow');
    
    // Check environment SESSION_ID
    const envSessionID = process.env.SESSION_ID?.trim();

    if (envSessionID && envSessionID.startsWith('KELVIN-MD')) {
        log("Found new SESSION_ID in environment variable.", 'magenta');
        clearSessionFiles();
        global.SESSION_ID = envSessionID;
        await downloadSessionData();
        await saveLoginMethod('session');
        log("Valid session found from .env...", 'green');
    } else {
        log("[ALERT] No new SESSION_ID found in .env", 'blue');
        log("Checking stored session...", 'blue');
        await checkSessionIntegrityAndClean();
    }

    await loadAllPlugins();

    const { version } = await fetchLatestBaileysVersion();
    const msgRetryCounterCache = new NodeCache();
    
    const {
        state,
        saveCreds 
    } = await useMultiFileAuthState('./session');
    
    const kelvin = makeWASocket({
        version,
        logger: pino({ level: "silent" }),
        printQRInTerminal: false,
        browser: ["Ubuntu", "Chrome", "20.0.04"],
        auth: {
            creds: state.creds,
            keys: makeCacheableSignalKeyStore(state.keys, pino({ level: "fatal" }).child({ level: "fatal" })),
        },
        markOnlineOnConnect: true,
        generateHighQualityLinkPreview: false,
        syncFullHistory: false,
        getMessage: async (key) => {
            let jid = jidNormalizedUser(key.remoteJid);
            let msg = await store.loadMessage(jid, key.id);
            return msg?.message || "";
        },
        msgRetryCounterCache,
        // Add connection options to help with timeouts
        connectTimeoutMs: 60000, // 60 seconds
        keepAliveIntervalMs: 30000, // 30 seconds
        retryRequestDelayMs: 2000 // 2 seconds
    });

    // Connection timeout monitor
    let connectionMonitor = setTimeout(() => {
        if (!kelvin.user) {
            console.log(chalk.red(`\n❌ Connection timeout - No connection established within ${CONNECTION_TIMEOUT/1000} seconds`));
            console.log(chalk.yellow(`🔄 Restarting bot...`));
            process.exit(1);
        }
    }, CONNECTION_TIMEOUT);

    // Handle pairing code if needed with auto-restart on expiry
    if (!sessionExists() && !envSessionID) {
        try {
            const usePairingCode = true;
            if (usePairingCode && !kelvin.authState.creds.registered) {
                while (global.pairingRetryCount < MAX_PAIRING_RETRIES) {
                    try {
                        const phoneNumber = await question(chalk.greenBright(`\n📱 Please provide your WhatsApp number (e.g., 256742932677):\n> `));
                        
                        // Validate phone number (basic check)
                        if (!phoneNumber || phoneNumber.trim() === '') {
                            console.log(chalk.red(`❌ Invalid phone number!`));
                            global.pairingRetryCount++;
                            continue;
                        }

                        console.log(chalk.yellow(`⏳ Requesting pairing code (Attempt ${global.pairingRetryCount + 1}/${MAX_PAIRING_RETRIES})...`));
                        
                        const pairingPromise = kelvin.requestPairingCode(phoneNumber.trim());
                        const timeoutPromise = new Promise((_, reject) => {
                            setTimeout(() => reject(new Error('PAIRING_CODE_TIMEOUT')), PAIRING_CODE_TIMEOUT);
                        });

                        let code = await Promise.race([pairingPromise, timeoutPromise]);
                        
                        // Display pairing code without box
                        console.log(chalk.green(`\n✅ Your Pairing Code: ${chalk.bold(code)}`));
                        console.log(chalk.yellow(`⏰ This code will expire in ${PAIRING_CODE_TIMEOUT/1000} seconds if not used...`));
                        
                        await saveLoginMethod('number');
                        
                        // Reset retry count on successful code generation
                        global.pairingRetryCount = 0;
                        
                        // Create pairing timeout handler
                        let pairingTimeout = setTimeout(() => {
                            console.log(chalk.red(`\n❌ Pairing code expired! No connection established within ${PAIRING_CODE_TIMEOUT/1000} seconds.`));
                            global.pairingRetryCount++;
                            
                            if (global.pairingRetryCount < MAX_PAIRING_RETRIES) {
                                console.log(chalk.yellow(`🔄 Auto-restarting to request new pairing code... (${global.pairingRetryCount}/${MAX_PAIRING_RETRIES})`));
                                clearTimeout(connectionMonitor);
                                kelvin.end();
                                setTimeout(() => process.exit(1), 2000);
                            } else {
                                console.log(chalk.red(`❌ Max retries (${MAX_PAIRING_RETRIES}) reached. Please check your number and try again later.`));
                                console.log(chalk.yellow(`🔄 Restarting in 10 seconds...`));
                                setTimeout(() => process.exit(1), 10000);
                            }
                        }, PAIRING_CODE_TIMEOUT + 10000);

                        // Listen for connection update to clear timeout
                        const connectionHandler = (update) => {
                            if (update.connection === 'open') {
                                clearTimeout(pairingTimeout);
                                clearTimeout(connectionMonitor);
                                console.log(chalk.green(`\n✅ Successfully connected!`));
                                kelvin.ev.off('connection.update', connectionHandler);
                            }
                        };
                        
                        kelvin.ev.on('connection.update', connectionHandler);
                        
                        break;
                        
                    } catch (error) {
                        global.pairingRetryCount++;
                        
                        if (error.message === 'PAIRING_CODE_TIMEOUT') {
                            console.log(chalk.red(`\n❌ Pairing code request timed out!`));
                        } else {
                            console.log(chalk.red(`\n❌ Error: ${error.message}`));
                        }
                        
                        if (global.pairingRetryCount < MAX_PAIRING_RETRIES) {
                            console.log(chalk.yellow(`🔄 Auto-restarting in 5 seconds... (${global.pairingRetryCount}/${MAX_PAIRING_RETRIES})`));
                            await sleep(5000);
                            process.exit(1);
                        } else {
                            console.log(chalk.red(`❌ Max retries (${MAX_PAIRING_RETRIES}) reached. Exiting...`));
                            console.log(chalk.yellow(`🔄 Restarting in 10 seconds...`));
                            await sleep(10000);
                            process.exit(1);
                        }
                    }
                }
            }
        } catch (e) {
            console.error("Failed to request pairing code:", e);
            console.log(chalk.yellow(`🔄 Auto-restarting in 5 seconds...`));
            await sleep(5000);
            process.exit(1);
        }
    }

    store.bind(kelvin.ev);
    
    // Message handler with backup
    kelvin.ev.on('messages.upsert', async chatUpdate => {
        try {
            // Message backup
            for (const msg of chatUpdate.messages) {
                if (!msg.message) continue;
                let chatId = msg.key.remoteJid;
                let messageId = msg.key.id;
                if (!global.messageBackup[chatId]) {
                    global.messageBackup[chatId] = {};
                }
                let textMessage = msg.message?.conversation || msg.message?.extendedTextMessage?.text || null;
                if (textMessage) {
                    let savedMessage = { 
                        sender: msg.key.participant || msg.key.remoteJid, 
                        text: textMessage, 
                        timestamp: msg.messageTimestamp 
                    };
                    if (!global.messageBackup[chatId][messageId]) {
                        global.messageBackup[chatId][messageId] = savedMessage;
                        saveStoredMessages(global.messageBackup);
                    }
                }
            }

            let mek = chatUpdate.messages[0];
            if (!mek.message) return;
            mek.message = (Object.keys(mek.message)[0] === 'ephemeralMessage') ? 
                mek.message.ephemeralMessage.message : mek.message;
            
            if (mek.key && mek.key.remoteJid === 'status@broadcast') {
                return;
            }
            
            let m = smsg(kelvin, mek, store);
            
            require("./system")(kelvin, m, chatUpdate, store);
            
        } catch (err) {
            console.error(err);        
        }
    });

    kelvin.decodeJid = (jid) => {
        if (!jid) return jid;
        if (/:\d+@/gi.test(jid)) {
            let decode = jidDecode(jid) || {};
            return decode.user && decode.server && decode.user + '@' + decode.server || jid;
        } else return jid;
    };

    kelvin.ev.on('contacts.update', update => {
        for (let contact of update) {
            let id = kelvin.decodeJid(contact.id);
            if (store && store.contacts) store.contacts[id] = { id, name: contact.notify };
        }
    });

    kelvin.public = global.status || true;

    // Main connection update handler
    kelvin.ev.on('connection.update', async (update) => {
        const { connection, lastDisconnect, qr } = update;
        
        // Handle QR code if needed (fallback)
        if (qr) {
            console.log(chalk.yellow('QR Code received (scan with WhatsApp):'));
            console.log(qr);
        }
        
        if (connection === 'close') {
            global.isBotConnected = false;
            
            // Extract error information
            const error = lastDisconnect?.error;
            let statusCode = error?.output?.statusCode || error?.statusCode || error?.code;
            const errorMessage = error?.message || error?.toString() || 'Unknown error';
            
            // Log detailed error info
            console.log(chalk.red(`\n❌ Connection closed`));
            console.log(chalk.yellow(`📋 Status Code: ${statusCode || 'N/A'}`));
            console.log(chalk.yellow(`📋 Error: ${errorMessage}`));
            
            // Check for permanent logout
            const permanentLogout = statusCode === DisconnectReason.loggedOut || 
                                   statusCode === 401 ||
                                   errorMessage.toLowerCase().includes('logged out') ||
                                   errorMessage.includes('401');
            
            if (permanentLogout) {
                log(chalk.bgRed.black(`\n💥 Logged out! Status: ${statusCode}`), 'red');
                log('🗑️ Deleting session folder...', 'yellow');
                clearSessionFiles();
                log('Session cleaned. Restarting in 5 seconds...', 'blue');
                await sleep(5000);
                process.exit(1);
                return;
            }
            
            // Handle timeout/408 errors
            const is408Handled = await handle408Error(error);
            if (is408Handled) {
                console.log(chalk.blue(`🔄 Reconnecting... (Attempt ${global.errorRetryCount}/${MAX_RETRIES})`));
                kelvinstart();
                return;
            }
            
            // For other errors, reconnect after delay
            console.log(chalk.yellow(`🔄 Reconnecting in 3 seconds...`));
            await sleep(3000);
            kelvinstart();
            
        } else if (connection === "connecting") {
            console.log(chalk.blue('🔄 Connecting to WhatsApp...'));
        } else if (connection === "open") {
            console.log(chalk.green(`✅ Connected successfully!`));
            console.log(chalk.yellow(`📱 Connected as: ` + JSON.stringify(kelvin.user, null, 2)));
            log('KELVIN-X Connected', 'yellow');
            log(`Contact: 256742932677`, 'yellow');
            
            // Reset error count on successful connection
            global.errorRetryCount = 0;
            deleteErrorCountFile();
            
            await sendWelcomeMessage(kelvin);
        }
    });

    // Utility functions
    kelvin.sendText = (jid, text, quoted = '', options) => {
        kelvin.sendMessage(jid, { text: text, ...options }, { quoted });
    }
    
    kelvin.downloadAndSaveMediaMessage = async (message, filename, attachExtension = true) => {
        let quoted = message.msg ? message.msg : message;
        let mime = (message.msg || message).mimetype || "";
        let messageType = message.mtype
            ? message.mtype.replace(/Message/gi, "")
            : mime.split("/")[0];

        const stream = await downloadContentFromMessage(quoted, messageType);
        let buffer = Buffer.from([]);
        for await (const chunk of stream) {
            buffer = Buffer.concat([buffer, chunk]);
        }

        let type = await FileType.fromBuffer(buffer);
        let trueFileName = attachExtension ? (filename + "." + (type ? type.ext : 'bin')) : filename;
        await fs.writeFileSync(trueFileName, buffer);
        return trueFileName;
    };

    kelvin.downloadMediaMessage = async (message) => {
        let mime = (message.msg || message).mimetype || '';
        let messageType = message.mtype ? message.mtype.replace(/Message/gi, '') : mime.split('/')[0];
        const stream = await downloadContentFromMessage(message, messageType);
        let buffer = Buffer.from([]);
        for await (const chunk of stream) {
            buffer = Buffer.concat([buffer, chunk]);
        }
        return buffer;
    };
    
    kelvin.ev.on('creds.update', saveCreds);

    // Background intervals for cleanup
    setInterval(() => {
        try {
            const sessionPath = path.join(sessionDir);
            if (!fs.existsSync(sessionPath)) return;
            
            fs.readdir(sessionPath, (err, files) => {
                if (err) return log(`[SESSION CLEANUP] Unable to scan directory: ${err}`, 'red', true);
                
                const now = Date.now();
                const filteredArray = files.filter((item) => {
                    const filePath = path.join(sessionPath, item);
                    try {
                        const stats = fs.statSync(filePath);
                        return ((item.startsWith("pre-key") || item.startsWith("sender-key") || 
                                item.startsWith("session-") || item.startsWith("app-state")) &&
                                item !== 'creds.json' && now - stats.mtimeMs > 2 * 24 * 60 * 60 * 1000);
                    } catch (statError) {
                        return false;
                    }
                });
                
                if (filteredArray.length > 0) {
                    log(`[Session Cleanup] Found ${filteredArray.length} old session files. Clearing...`, 'yellow');
                    filteredArray.forEach((file) => {
                        const filePath = path.join(sessionPath, file);
                        try { fs.unlinkSync(filePath); } catch (e) {}
                    });
                }
            });
        } catch (error) {
            log(`[SESSION CLEANUP] Error: ${error.message}`, 'red', true);
        }
    }, 7200000);

    setInterval(cleanupOldMessages, 60 * 60 * 1000);
    setInterval(() => cleanupJunkFiles(kelvin), 30000);

    return kelvin;
}

// Start the bot
kelvinstart().catch(err => log(`Fatal error starting bot: ${err.message}`, 'red', true));

// Process error handlers
process.on('uncaughtException', (err) => log(`Uncaught Exception: ${err.message}`, 'red', true));
process.on('unhandledRejection', (err) => log(`Unhandled Rejection: ${err.message}`, 'red', true));

// File watcher for auto-restart on changes
let file = require.resolve(__filename);
require('fs').watchFile(file, () => {
    require('fs').unwatchFile(file);
    console.log('\x1b[0;32m' + __filename + ' \x1b[1;32mupdated!\x1b[0m');
    delete require.cache[file];
    require(file);
});